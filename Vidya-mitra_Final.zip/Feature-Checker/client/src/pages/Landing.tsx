import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Zap, Shield, Globe } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed w-full top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="font-display font-bold text-2xl tracking-tighter text-primary">Learn.AI</div>
          <div className="flex gap-4">
            <Button variant="ghost" asChild><a href="/api/login">Log In</a></Button>
            <Button asChild><a href="/api/login">Get Started</a></Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-display font-bold leading-[1.1] tracking-tight text-balance">
              Master Your Career with <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">AI-Powered</span> Learning
            </h1>
            <p className="text-xl text-muted-foreground text-balance max-w-lg">
              Personalized courses, AI interview coaching, and smart resume building—all in one platform designed to get you hired.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="text-lg px-8 h-14 rounded-full shadow-xl shadow-primary/20" asChild>
                <a href="/api/login">Start Learning Free <ArrowRight className="ml-2 w-5 h-5" /></a>
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 h-14 rounded-full">
                View Demo
              </Button>
            </div>
            <div className="flex items-center gap-6 text-sm text-muted-foreground pt-4">
              <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> No credit card required</span>
              <span className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-green-500" /> 14-day free trial</span>
            </div>
          </div>
          
          <div className="relative animate-slide-up">
            <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-accent/20 rounded-full blur-3xl -z-10" />
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&auto=format&fit=crop" 
              alt="Students learning" 
              className="rounded-2xl shadow-2xl border border-white/10 rotate-2 hover:rotate-0 transition-transform duration-500"
            />
            
            {/* Floating Card */}
            <div className="absolute -bottom-6 -left-6 bg-card p-4 rounded-xl shadow-xl border border-border animate-bounce duration-[3000ms]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-bold text-sm">Course Completed</p>
                  <p className="text-xs text-muted-foreground">You earned a new badge!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold font-display mb-4">Everything you need to grow</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Our platform combines traditional learning with cutting-edge AI tools.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={Globe}
              title="Interactive Courses"
              description="Learn by doing with interactive modules, quizzes, and hands-on projects."
            />
            <FeatureCard 
              icon={Zap}
              title="AI Interview Coach"
              description="Practice behavioral and technical interviews with real-time AI feedback."
            />
            <FeatureCard 
              icon={Shield}
              title="Smart Resumes"
              description="Build ATS-friendly resumes that automatically tailor to job descriptions."
            />
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2024 Learn.AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: any) {
  return (
    <div className="p-8 rounded-2xl bg-card border border-border hover:shadow-lg transition-all hover:-translate-y-1">
      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-6">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  );
}
