import { useState, useEffect } from "react";
import { Shell } from "@/components/layout/Shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useResumes, useCreateResume, useImproveResume } from "@/hooks/use-resumes";
import { useToast } from "@/hooks/use-toast";
import { Wand2, Download, Save, Plus } from "lucide-react";
import ReactMarkdown from "react-markdown";

export default function ResumeBuilder() {
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("My Resume");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  
  const { data: resumes, isLoading } = useResumes();
  const createResume = useCreateResume();
  const improveResume = useImproveResume();
  const { toast } = useToast();

  const handleSave = async () => {
    try {
      await createResume.mutateAsync({ title, content });
      toast({ title: "Success", description: "Resume saved successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to save resume", variant: "destructive" });
    }
  };

  const handleImprove = async () => {
    if (!selectedId) return;
    try {
      const result = await improveResume.mutateAsync(selectedId);
      if (result.improvements?.optimizedContent) {
        setContent(result.improvements.optimizedContent);
        toast({ title: "Success", description: "Resume improved by AI" });
      }
    } catch (error) {
      toast({ title: "Error", description: "AI improvement failed", variant: "destructive" });
    }
  };

  return (
    <Shell>
      <div className="h-full flex flex-col gap-6 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Input 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              className="max-w-[300px]"
              placeholder="Resume Title"
            />
            <Button variant="outline" size="sm" onClick={() => { setSelectedId(null); setContent(""); setTitle("New Resume"); }}>
              <Plus className="w-4 h-4 mr-2" /> New
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleImprove} disabled={!selectedId || improveResume.isPending}>
              <Wand2 className="w-4 h-4 mr-2" /> {improveResume.isPending ? "Improving..." : "AI Improve"}
            </Button>
            <Button onClick={handleSave} disabled={createResume.isPending}>
              <Save className="w-4 h-4 mr-2" /> Save
            </Button>
            <Button variant="secondary">
              <Download className="w-4 h-4 mr-2" /> Export
            </Button>
          </div>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-hidden">
          <Card className="flex flex-col overflow-hidden">
            <CardContent className="flex-1 p-0">
              <Textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your resume in Markdown format..."
                className="w-full h-full resize-none border-0 p-6 focus-visible:ring-0 font-mono text-sm"
              />
            </CardContent>
          </Card>

          <Card className="flex flex-col overflow-hidden bg-white dark:bg-zinc-950">
            <CardContent className="flex-1 overflow-y-auto p-8 prose dark:prose-invert max-w-none">
              <ReactMarkdown>{content || "*Your preview will appear here*"}</ReactMarkdown>
            </CardContent>
          </Card>
        </div>
        
        {resumes && resumes.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-2">
            {resumes.map((r) => (
              <Button 
                key={r.id} 
                variant={selectedId === r.id ? "default" : "outline"}
                size="sm"
                onClick={() => { setSelectedId(r.id); setContent(r.content); setTitle(r.title); }}
              >
                {r.title}
              </Button>
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}
