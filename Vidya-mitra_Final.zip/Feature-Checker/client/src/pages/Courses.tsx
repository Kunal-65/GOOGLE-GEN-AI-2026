import { useState } from "react";
import { useCourses } from "@/hooks/use-courses";
import { Shell } from "@/components/layout/Shell";
import { PageHeader } from "@/components/ui/PageHeader";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Filter, PlayCircle } from "lucide-react";
import { Link } from "wouter";

export default function Courses() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const { data: courses, isLoading } = useCourses(category, search);

  const categories = ["Development", "Design", "Business", "Marketing", "Data Science"];

  return (
    <Shell>
      <PageHeader title="Course Library" description="Expand your knowledge with our curated courses.">
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input 
            placeholder="Search courses..." 
            className="pl-9 bg-card"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </PageHeader>

      {/* Category Filters */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
        <Button 
          variant={category === "" ? "default" : "outline"} 
          onClick={() => setCategory("")}
          className="rounded-full px-6"
        >
          All
        </Button>
        {categories.map((cat) => (
          <Button 
            key={cat}
            variant={category === cat ? "default" : "outline"} 
            onClick={() => setCategory(cat)}
            className="rounded-full px-6 whitespace-nowrap"
          >
            {cat}
          </Button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-[340px] rounded-2xl bg-muted/20 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-slide-up">
          {courses?.map((course) => (
            <Link key={course.id} href={`/courses/${course.id}`}>
              <Card className="h-full flex flex-col overflow-hidden hover:shadow-xl hover:border-primary/50 transition-all duration-300 group cursor-pointer border-border/60">
                <div className="relative h-48 overflow-hidden">
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors z-10" />
                  <img 
                    src={course.imageUrl || "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&auto=format&fit=crop"} 
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <Badge className="absolute top-4 left-4 z-20 bg-background/90 text-foreground hover:bg-background shadow-sm backdrop-blur-sm">
                    {course.category}
                  </Badge>
                </div>
                
                <CardHeader className="space-y-2 pb-3">
                  <div className="flex justify-between items-start">
                    <h3 className="font-bold font-display text-lg leading-tight line-clamp-2 group-hover:text-primary transition-colors">
                      {course.title}
                    </h3>
                  </div>
                </CardHeader>
                
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {course.description}
                  </p>
                </CardContent>
                
                <CardFooter className="pt-0 border-t border-border/30 mt-auto p-4 flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <PlayCircle className="w-4 h-4" />
                    <span>{Math.round(course.duration / 60)}h {course.duration % 60}m</span>
                  </div>
                  <Badge variant="outline" className={
                    course.difficulty === 'Beginner' ? 'text-green-500 border-green-200 bg-green-50/50' :
                    course.difficulty === 'Intermediate' ? 'text-blue-500 border-blue-200 bg-blue-50/50' :
                    'text-orange-500 border-orange-200 bg-orange-50/50'
                  }>
                    {course.difficulty}
                  </Badge>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </Shell>
  );
}
