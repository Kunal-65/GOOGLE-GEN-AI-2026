import { useInterviews, useCreateInterview, useAnalyzeInterview } from "@/hooks/use-interviews";
import { Shell } from "@/components/layout/Shell";
import { PageHeader } from "@/components/ui/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mic, Play, Plus, BarChart3, Loader2 } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";

export default function Interviews() {
  const { data: interviews, isLoading } = useInterviews();
  const createInterview = useCreateInterview();
  
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({ title: "", type: "Behavioral" });

  const handleCreate = async () => {
    await createInterview.mutateAsync(formData);
    setIsOpen(false);
    setFormData({ title: "", type: "Behavioral" });
  };

  return (
    <Shell>
      <PageHeader title="Interview Prep" description="Practice with AI and get instant feedback.">
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Session
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Start New Interview</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Session Title</Label>
                <Input 
                  placeholder="e.g. Frontend Engineer Mock" 
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Interview Type</Label>
                <Select 
                  value={formData.type} 
                  onValueChange={val => setFormData({ ...formData, type: val })}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Behavioral">Behavioral (Soft Skills)</SelectItem>
                    <SelectItem value="Technical">Technical (Coding/System Design)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleCreate} 
                disabled={!formData.title || createInterview.isPending} 
                className="w-full"
              >
                {createInterview.isPending ? "Creating..." : "Start Session"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {interviews?.map((interview) => (
          <Card key={interview.id} className="hover:shadow-lg transition-all cursor-pointer group">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <p className="text-xs font-bold text-primary uppercase tracking-wider">{interview.type}</p>
                  <CardTitle className="group-hover:text-primary transition-colors">{interview.title}</CardTitle>
                </div>
                {interview.score && (
                  <div className="flex flex-col items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-700 font-bold border border-green-200">
                    {interview.score}
                    <span className="text-[10px] font-normal">Score</span>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {new Date(interview.createdAt!).toLocaleDateString()} • {interview.transcript?.length || 0} Interactions
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground">
                <Link href={`/interviews/${interview.id}`}>
                  {interview.feedback ? "View Analysis" : "Continue Session"}
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </Shell>
  );
}
