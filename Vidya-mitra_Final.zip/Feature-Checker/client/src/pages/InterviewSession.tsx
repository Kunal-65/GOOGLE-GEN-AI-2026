import { useInterview, useAnalyzeInterview } from "@/hooks/use-interviews";
import { useVoiceRecorder, useVoiceStream } from "@/replit_integrations/audio";
import { Shell } from "@/components/layout/Shell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useRoute } from "wouter";
import { Mic, Square, Loader2, Sparkles, AlertCircle } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

export default function InterviewSession() {
  const [, params] = useRoute("/interviews/:id");
  const interviewId = parseInt(params?.id || "0");
  const { data: interview } = useInterview(interviewId);
  const analyze = useAnalyzeInterview();
  
  const [transcript, setTranscript] = useState<string>("");
  const [messages, setMessages] = useState<{role: 'user'|'ai', text: string}[]>([]);
  
  const recorder = useVoiceRecorder();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const stream = useVoiceStream({
    onUserTranscript: (text) => {
      setMessages(prev => [...prev, { role: 'user', text }]);
    },
    onTranscript: (_, full) => {
      setTranscript(full);
    },
    onComplete: (fullText) => {
      setMessages(prev => [...prev, { role: 'ai', text: fullText }]);
      setTranscript("");
    }
  });

  const handleMicClick = async () => {
    if (recorder.state === "recording") {
      const blob = await recorder.stopRecording();
      // Send audio for processing
      await stream.streamVoiceResponse(
        `/api/conversations/${interviewId}/messages`, 
        blob
      );
    } else {
      await recorder.startRecording();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, transcript]);

  return (
    <Shell>
      <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold font-display">{interview?.title}</h1>
            <p className="text-muted-foreground">AI Interviewer • {interview?.type}</p>
          </div>
          <Button 
            onClick={() => analyze.mutate(interviewId)}
            disabled={analyze.isPending}
            variant="secondary"
          >
            {analyze.isPending ? <Loader2 className="animate-spin w-4 h-4 mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
            Analyze Session
          </Button>
        </div>

        {/* Chat Area */}
        <Card className="flex-1 overflow-hidden flex flex-col bg-slate-50 dark:bg-slate-900 border-border">
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50">
                <Mic className="w-12 h-12 mb-4" />
                <p>Tap the microphone to start speaking</p>
              </div>
            )}
            
            {messages.map((msg, idx) => (
              <div key={idx} className={cn(
                "flex w-full",
                msg.role === 'user' ? "justify-end" : "justify-start"
              )}>
                <div className={cn(
                  "max-w-[80%] rounded-2xl px-5 py-3 shadow-sm",
                  msg.role === 'user' 
                    ? "bg-primary text-primary-foreground rounded-tr-none" 
                    : "bg-white dark:bg-slate-800 text-foreground rounded-tl-none border border-border"
                )}>
                  {msg.text}
                </div>
              </div>
            ))}
            
            {transcript && (
              <div className="flex w-full justify-start">
                <div className="max-w-[80%] rounded-2xl px-5 py-3 bg-white dark:bg-slate-800 border border-border text-muted-foreground animate-pulse rounded-tl-none">
                  {transcript}
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Controls */}
          <div className="p-6 bg-card border-t border-border flex justify-center">
            <button
              onClick={handleMicClick}
              className={cn(
                "w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-105",
                recorder.state === "recording" 
                  ? "bg-destructive text-white animate-pulse ring-4 ring-destructive/30" 
                  : "bg-primary text-white hover:bg-primary/90"
              )}
            >
              {recorder.state === "recording" ? (
                <Square className="w-6 h-6 fill-current" />
              ) : (
                <Mic className="w-8 h-8" />
              )}
            </button>
          </div>
        </Card>
      </div>
    </Shell>
  );
}
