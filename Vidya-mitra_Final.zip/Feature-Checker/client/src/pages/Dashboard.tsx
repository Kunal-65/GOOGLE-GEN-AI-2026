import { useAuth } from "@/hooks/use-auth";
import { useCourses, useCourseProgress } from "@/hooks/use-courses";
import { useBadges } from "@/hooks/use-gamification";
import { Shell } from "@/components/layout/Shell";
import { PageHeader } from "@/components/ui/PageHeader";
import { LearningChart } from "@/components/dashboard/LearningChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, Clock, Trophy, Target, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: courses } = useCourses();
  const { data: badges } = useBadges();

  // Mock progress for demo
  const progress = 65;

  return (
    <Shell>
      <PageHeader 
        title={`Welcome back, ${user?.firstName}!`}
        description="Here's an overview of your learning journey."
      >
        <Button asChild>
          <Link href="/courses">Explore Courses</Link>
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard icon={Clock} title="Time Learned" value="12h 30m" trend="+2.5h this week" />
        <StatCard icon={BookOpen} title="Courses in Progress" value="3" trend="2 completed" />
        <StatCard icon={Trophy} title="Badges Earned" value={badges?.filter(b => b.earned).length || 0} trend="Top 10% student" />
        <StatCard icon={Target} title="Current Streak" value="5 Days" trend="Keep it up!" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart Section */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="shadow-lg border-border/50">
            <CardHeader>
              <CardTitle>Weekly Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <LearningChart />
            </CardContent>
          </Card>

          <Card className="shadow-lg border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Continue Learning</CardTitle>
              <Link href="/courses" className="text-sm text-primary hover:underline">View All</Link>
            </CardHeader>
            <CardContent className="space-y-4">
              {courses?.slice(0, 3).map((course) => (
                <div key={course.id} className="flex items-center gap-4 p-4 rounded-xl bg-muted/30 border border-transparent hover:border-border transition-all">
                  <div className="w-16 h-16 rounded-lg bg-cover bg-center shrink-0" 
                    style={{ backgroundImage: `url(${course.imageUrl || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&auto=format&fit=crop'})` }} 
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold truncate">{course.title}</h4>
                    <p className="text-sm text-muted-foreground">{course.category} • {course.difficulty}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <Progress value={progress} className="h-2" />
                      <span className="text-xs text-muted-foreground">{progress}%</span>
                    </div>
                  </div>
                  <Button size="icon" variant="ghost" asChild>
                    <Link href={`/courses/${course.id}`}><ArrowRight className="w-5 h-5" /></Link>
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
          <Card className="bg-primary text-primary-foreground shadow-xl shadow-primary/20 border-none">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-300" />
                Latest Achievement
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-4">
                <div className="w-20 h-20 mx-auto bg-white/20 rounded-full flex items-center justify-center mb-4 text-4xl">
                  🚀
                </div>
                <h3 className="font-bold text-lg">Fast Starter</h3>
                <p className="text-primary-foreground/80 text-sm mt-1">Completed first module in record time!</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recommended for You</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-3 rounded-lg border border-border hover:bg-muted/30 transition-colors cursor-pointer">
                <p className="font-medium text-sm">Advanced React Patterns</p>
                <p className="text-xs text-muted-foreground mt-1">Because you liked "React Basics"</p>
              </div>
              <div className="p-3 rounded-lg border border-border hover:bg-muted/30 transition-colors cursor-pointer">
                <p className="font-medium text-sm">System Design Interview</p>
                <p className="text-xs text-muted-foreground mt-1">Popular in "Backend Engineering"</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Shell>
  );
}

function StatCard({ icon: Icon, title, value, trend }: any) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
            <Icon className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
            <h3 className="text-2xl font-bold font-display">{value}</h3>
            <p className="text-xs text-primary mt-0.5">{trend}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
