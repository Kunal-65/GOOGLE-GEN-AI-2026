import { useCourse, useCourseProgress, useUpdateProgress } from "@/hooks/use-courses";
import { Shell } from "@/components/layout/Shell";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useRoute } from "wouter";
import { CheckCircle2, Circle, Play, ArrowLeft } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

export default function CourseDetails() {
  const [, params] = useRoute("/courses/:id");
  const courseId = parseInt(params?.id || "0");
  
  const { data: course, isLoading } = useCourse(courseId);
  const { data: progress } = useCourseProgress(courseId);
  const updateProgress = useUpdateProgress();
  
  const [activeModuleId, setActiveModuleId] = useState<number | null>(null);

  useEffect(() => {
    if (course?.modules.length && activeModuleId === null) {
      setActiveModuleId(course.modules[0].id);
    }
  }, [course, activeModuleId]);

  const activeModule = course?.modules.find(m => m.id === activeModuleId);
  const isCompleted = (moduleId: number) => progress?.completedModules.includes(moduleId);

  const handleComplete = (moduleId: number) => {
    updateProgress.mutate({ 
      courseId, 
      moduleId, 
      completed: !isCompleted(moduleId) 
    });
  };

  if (isLoading || !course) return <CourseSkeleton />;

  return (
    <Shell>
      <div className="flex flex-col lg:flex-row h-[calc(100vh-8rem)] gap-6">
        {/* Main Content Area */}
        <div className="flex-1 flex flex-col bg-card rounded-2xl shadow-lg border border-border overflow-hidden">
          {/* Header */}
          <div className="p-6 border-b border-border bg-muted/10 flex items-center justify-between">
            <h2 className="text-xl font-bold font-display">{activeModule?.title}</h2>
            <Button 
              onClick={() => activeModule && handleComplete(activeModule.id)}
              variant={isCompleted(activeModule?.id || 0) ? "outline" : "default"}
              disabled={updateProgress.isPending}
            >
              {isCompleted(activeModule?.id || 0) ? (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Completed
                </>
              ) : (
                "Mark as Complete"
              )}
            </Button>
          </div>

          {/* Content */}
          <ScrollArea className="flex-1 p-8">
            <div className="prose prose-slate dark:prose-invert max-w-none">
              <ReactMarkdown>{activeModule?.content || "No content available."}</ReactMarkdown>
            </div>
          </ScrollArea>
        </div>

        {/* Sidebar / Playlist */}
        <div className="w-full lg:w-80 bg-card rounded-2xl shadow-lg border border-border flex flex-col shrink-0">
          <div className="p-4 border-b border-border">
            <h3 className="font-bold font-display">{course.title}</h3>
            <p className="text-xs text-muted-foreground mt-1">
              {progress?.progress || 0}% Completed
            </p>
            <div className="h-1.5 w-full bg-secondary rounded-full mt-2 overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-500" 
                style={{ width: `${progress?.progress || 0}%` }} 
              />
            </div>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-2 space-y-1">
              {course.modules.sort((a, b) => a.order - b.order).map((module, index) => (
                <button
                  key={module.id}
                  onClick={() => setActiveModuleId(module.id)}
                  className={cn(
                    "w-full flex items-start gap-3 p-3 rounded-lg text-left transition-colors text-sm",
                    activeModuleId === module.id 
                      ? "bg-primary/10 text-primary font-medium" 
                      : "hover:bg-muted/50 text-muted-foreground"
                  )}
                >
                  <div className="mt-0.5 shrink-0">
                    {isCompleted(module.id) ? (
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                    ) : (
                      <span className="flex items-center justify-center w-4 h-4 rounded-full border border-current text-[10px]">
                        {index + 1}
                      </span>
                    )}
                  </div>
                  <span className="leading-tight">{module.title}</span>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>
      </div>
    </Shell>
  );
}

function CourseSkeleton() {
  return (
    <Shell>
      <div className="h-full flex gap-6 animate-pulse">
        <div className="flex-1 bg-muted/20 rounded-2xl h-[600px]" />
        <div className="w-80 bg-muted/20 rounded-2xl h-[600px]" />
      </div>
    </Shell>
  );
}
