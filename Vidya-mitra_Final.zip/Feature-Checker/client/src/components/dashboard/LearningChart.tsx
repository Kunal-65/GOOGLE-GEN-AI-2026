import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'Mon', minutes: 45 },
  { name: 'Tue', minutes: 90 },
  { name: 'Wed', minutes: 30 },
  { name: 'Thu', minutes: 60 },
  { name: 'Fri', minutes: 120 },
  { name: 'Sat', minutes: 75 },
  { name: 'Sun', minutes: 20 },
];

export function LearningChart() {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis 
            dataKey="name" 
            stroke="hsl(var(--muted-foreground))" 
            fontSize={12} 
            tickLine={false} 
            axisLine={false}
          />
          <YAxis 
            stroke="hsl(var(--muted-foreground))" 
            fontSize={12} 
            tickLine={false} 
            axisLine={false}
            tickFormatter={(value) => `${value}m`}
          />
          <Tooltip 
            cursor={{ fill: 'hsl(var(--muted)/0.3)' }}
            contentStyle={{ 
              backgroundColor: 'hsl(var(--card))', 
              borderColor: 'hsl(var(--border))', 
              borderRadius: '8px',
              boxShadow: 'var(--shadow-lg)'
            }}
          />
          <Bar dataKey="minutes" radius={[4, 4, 0, 0]}>
            {data.map((_, index) => (
              <Cell key={`cell-${index}`} fill={index === 4 ? 'hsl(var(--primary))' : 'hsl(var(--primary)/0.3)'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
