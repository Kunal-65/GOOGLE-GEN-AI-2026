import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  BookOpen, 
  Mic2, 
  FileText, 
  Users, 
  Settings, 
  LogOut,
  Bell
} from "lucide-react";
import { useNotifications } from "@/hooks/use-gamification";

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Courses", href: "/courses", icon: BookOpen },
  { name: "Interview Prep", href: "/interviews", icon: Mic2 },
  { name: "Resume Builder", href: "/resume", icon: FileText },
  { name: "Community", href: "/community", icon: Users },
  { name: "Settings", href: "/settings", icon: Settings },
];

export function AppSidebar() {
  const [location] = useLocation();
  const { logout, user } = useAuth();
  const { data: notifications } = useNotifications();
  
  const unreadCount = notifications?.filter(n => !n.read).length || 0;

  return (
    <div className="flex flex-col h-full min-h-screen w-64 bg-card border-r border-border fixed left-0 top-0 z-40">
      {/* Logo Area */}
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/25">
            <BookOpen className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="font-display font-bold text-xl leading-none">Learn.AI</h1>
            <span className="text-xs text-muted-foreground">Pro Platform</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = location === item.href || location.startsWith(item.href + "/");
          return (
            <Link key={item.name} href={item.href} className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative",
              isActive 
                ? "bg-primary/10 text-primary font-medium shadow-sm" 
                : "text-muted-foreground hover:bg-muted/50 hover:text-foreground"
            )}>
              <item.icon className={cn(
                "w-5 h-5 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
              )} />
              {item.name}
              {isActive && (
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary rounded-l-full" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* User Profile & Footer */}
      <div className="p-4 border-t border-border/50">
        {/* Notifications Widget */}
        <div className="mb-4 px-4 py-3 bg-muted/30 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Bell className="w-4 h-4" />
            Notifications
          </div>
          {unreadCount > 0 && (
            <span className="bg-destructive text-destructive-foreground text-xs font-bold px-2 py-0.5 rounded-full">
              {unreadCount}
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted/50 transition-colors">
          <img 
            src={user?.profileImageUrl || `https://ui-avatars.com/api/?name=${user?.firstName}+${user?.lastName}&background=random`} 
            alt="Profile"
            className="w-10 h-10 rounded-full border-2 border-background shadow-sm"
          />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate text-foreground">{user?.firstName} {user?.lastName}</p>
            <p className="text-xs text-muted-foreground truncate">Free Plan</p>
          </div>
          <button 
            onClick={() => logout()}
            className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
