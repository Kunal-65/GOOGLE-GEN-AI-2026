import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// Fetch all courses with optional filters
export function useCourses(category?: string, search?: string) {
  return useQuery({
    queryKey: [api.courses.list.path, category, search],
    queryFn: async () => {
      const url = new URL(api.courses.list.path, window.location.origin);
      if (category) url.searchParams.set("category", category);
      if (search) url.searchParams.set("search", search);
      
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch courses");
      return api.courses.list.responses[200].parse(await res.json());
    },
  });
}

// Fetch single course details including modules
export function useCourse(id: number) {
  return useQuery({
    queryKey: [api.courses.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.courses.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) throw new Error("Course not found");
      if (!res.ok) throw new Error("Failed to fetch course");
      return api.courses.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

// Fetch user progress for a specific course
export function useCourseProgress(courseId: number) {
  return useQuery({
    queryKey: [api.progress.get.path, courseId],
    queryFn: async () => {
      const url = buildUrl(api.progress.get.path, { courseId });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null; // No progress yet
      if (!res.ok) throw new Error("Failed to fetch progress");
      return api.progress.get.responses[200].parse(await res.json());
    },
    enabled: !!courseId,
  });
}

// Update user progress (mark module complete)
export function useUpdateProgress() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ courseId, moduleId, completed }: { courseId: number, moduleId: number, completed: boolean }) => {
      const url = buildUrl(api.progress.update.path, { courseId });
      const res = await fetch(url, {
        method: api.progress.update.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ moduleId, completed }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update progress");
      return api.progress.update.responses[200].parse(await res.json());
    },
    onSuccess: (_, { courseId }) => {
      queryClient.invalidateQueries({ queryKey: [api.progress.get.path, courseId] });
      queryClient.invalidateQueries({ queryKey: [api.badges.list.path] }); // Might earn a badge
    },
  });
}
