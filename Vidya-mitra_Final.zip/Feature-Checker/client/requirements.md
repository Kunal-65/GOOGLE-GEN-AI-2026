## Packages
framer-motion | Smooth animations for page transitions and micro-interactions
recharts | Data visualization for learning analytics
lucide-react | Beautiful icons for the interface
react-circular-progressbar | Progress visualization
react-markdown | Rendering course content and resumes
date-fns | Date formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
