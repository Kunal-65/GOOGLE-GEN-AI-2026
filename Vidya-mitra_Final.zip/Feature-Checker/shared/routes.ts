import { z } from 'zod';
import { 
  insertCourseSchema, 
  insertModuleSchema,
  insertInterviewSchema,
  insertResumeSchema,
  courses,
  modules,
  userProgress,
  interviews,
  resumes,
  badges,
  notifications
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  })
};

export const api = {
  // Courses & Learning
  courses: {
    list: {
      method: 'GET' as const,
      path: '/api/courses' as const,
      input: z.object({
        category: z.string().optional(),
        search: z.string().optional()
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof courses.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/courses/:id' as const,
      responses: {
        200: z.custom<typeof courses.$inferSelect & { modules: typeof modules.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
  },
  
  progress: {
    get: {
      method: 'GET' as const,
      path: '/api/courses/:courseId/progress' as const,
      responses: {
        200: z.custom<typeof userProgress.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    update: {
      method: 'POST' as const,
      path: '/api/courses/:courseId/progress' as const,
      input: z.object({
        moduleId: z.number(),
        completed: z.boolean(),
      }),
      responses: {
        200: z.custom<typeof userProgress.$inferSelect>(),
      },
    }
  },

  // Interviews
  interviews: {
    list: {
      method: 'GET' as const,
      path: '/api/interviews' as const,
      responses: {
        200: z.array(z.custom<typeof interviews.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/interviews' as const,
      input: insertInterviewSchema,
      responses: {
        201: z.custom<typeof interviews.$inferSelect>(),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/interviews/:id' as const,
      responses: {
        200: z.custom<typeof interviews.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    analyze: { // Trigger AI analysis
      method: 'POST' as const,
      path: '/api/interviews/:id/analyze' as const,
      responses: {
        200: z.custom<typeof interviews.$inferSelect>(),
      },
    }
  },

  // Resumes
  resumes: {
    list: {
      method: 'GET' as const,
      path: '/api/resumes' as const,
      responses: {
        200: z.array(z.custom<typeof resumes.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/resumes' as const,
      input: insertResumeSchema,
      responses: {
        201: z.custom<typeof resumes.$inferSelect>(),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/resumes/:id' as const,
      responses: {
        200: z.custom<typeof resumes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    improve: { // AI Improvement
      method: 'POST' as const,
      path: '/api/resumes/:id/improve' as const,
      responses: {
        200: z.custom<typeof resumes.$inferSelect>(),
      },
    }
  },

  // Gamification & Notifications
  badges: {
    list: {
      method: 'GET' as const,
      path: '/api/badges' as const,
      responses: {
        200: z.array(z.custom<typeof badges.$inferSelect & { earned: boolean }>()),
      },
    }
  },
  
  notifications: {
    list: {
      method: 'GET' as const,
      path: '/api/notifications' as const,
      responses: {
        200: z.array(z.custom<typeof notifications.$inferSelect>()),
      },
    },
    markRead: {
      method: 'PATCH' as const,
      path: '/api/notifications/:id/read' as const,
      responses: {
        200: z.custom<typeof notifications.$inferSelect>(),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
