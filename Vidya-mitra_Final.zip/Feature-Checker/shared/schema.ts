import { pgTable, text, serial, integer, boolean, timestamp, jsonb, primaryKey } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Import Auth & Chat models to re-export
export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

// === COURSES & LEARNING ===
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  difficulty: text("difficulty").notNull(), // Beginner, Intermediate, Advanced
  duration: integer("duration").notNull(), // in minutes
  imageUrl: text("image_url"),
  aiSummary: text("ai_summary"),
  published: boolean("published").default(false),
});

export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(), // Markdown content
  order: integer("order").notNull(),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // References auth.users.id
  courseId: integer("course_id").notNull(),
  completedModules: jsonb("completed_modules").$type<number[]>().default([]),
  progress: integer("progress").default(0), // Percentage 0-100
  lastAccessed: timestamp("last_accessed").defaultNow(),
  completed: boolean("completed").default(false),
});

// === INTERVIEWS ===
export const interviews = pgTable("interviews", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  type: text("type").notNull(), // Behavioral, Technical
  transcript: jsonb("transcript").$type<any[]>().default([]),
  feedback: jsonb("feedback").$type<any>(), // AI analysis
  score: integer("score"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RESUMES ===
export const resumes = pgTable("resumes", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(), // JSON or Markdown
  originalContent: text("original_content"),
  improvements: jsonb("improvements").$type<any>(), // AI suggestions
  version: integer("version").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

// === GAMIFICATION ===
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(), // Lucide icon name
  category: text("category").notNull(),
});

export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  badgeId: integer("badge_id").notNull(),
  awardedAt: timestamp("awarded_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // info, success, warning
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===
export const coursesRelations = relations(courses, ({ many }) => ({
  modules: many(modules),
}));

export const modulesRelations = relations(modules, ({ one }) => ({
  course: one(courses, {
    fields: [modules.courseId],
    references: [courses.id],
  }),
}));

export const userProgressRelations = relations(userProgress, ({ one }) => ({
  course: one(courses, {
    fields: [userProgress.courseId],
    references: [courses.id],
  }),
}));

export const userBadgesRelations = relations(userBadges, ({ one }) => ({
  badge: one(badges, {
    fields: [userBadges.badgeId],
    references: [badges.id],
  }),
}));

// === SCHEMAS ===
export const insertCourseSchema = createInsertSchema(courses).omit({ id: true });
export const insertModuleSchema = createInsertSchema(modules).omit({ id: true });
export const insertProgressSchema = createInsertSchema(userProgress).omit({ id: true, lastAccessed: true });
export const insertInterviewSchema = createInsertSchema(interviews).omit({ id: true, createdAt: true });
export const insertResumeSchema = createInsertSchema(resumes).omit({ id: true, createdAt: true });
export const insertBadgeSchema = createInsertSchema(badges).omit({ id: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });

// === TYPES ===
export type Course = typeof courses.$inferSelect;
export type Module = typeof modules.$inferSelect;
export type UserProgress = typeof userProgress.$inferSelect;
export type Interview = typeof interviews.$inferSelect;
export type Resume = typeof resumes.$inferSelect;
export type Badge = typeof badges.$inferSelect;
export type UserBadge = typeof userBadges.$inferSelect;
export type Notification = typeof notifications.$inferSelect;

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type InsertModule = z.infer<typeof insertModuleSchema>;
export type InsertProgress = z.infer<typeof insertProgressSchema>;
export type InsertInterview = z.infer<typeof insertInterviewSchema>;
export type InsertResume = z.infer<typeof insertResumeSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
