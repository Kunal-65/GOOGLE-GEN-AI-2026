import { 
  courses, modules, userProgress, interviews, resumes, badges, userBadges, notifications,
  type Course, type Module, type UserProgress, type Interview, type Resume, type Badge, type Notification,
  type InsertCourse, type InsertModule, type InsertProgress, type InsertInterview, type InsertResume, type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

// Import Auth storage to extend or use
import { authStorage } from "./replit_integrations/auth/storage";

export interface IStorage {
  // Courses
  getCourses(category?: string): Promise<Course[]>;
  getCourse(id: number): Promise<(Course & { modules: Module[] }) | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  createModule(module: InsertModule): Promise<Module>;

  // Progress
  getUserProgress(userId: string, courseId: number): Promise<UserProgress | undefined>;
  updateUserProgress(userId: string, courseId: number, moduleId: number, completed: boolean): Promise<UserProgress>;

  // Interviews
  getInterviews(userId: string): Promise<Interview[]>;
  getInterview(id: number): Promise<Interview | undefined>;
  createInterview(interview: InsertInterview): Promise<Interview>;
  updateInterview(id: number, updates: Partial<Interview>): Promise<Interview>;

  // Resumes
  getResumes(userId: string): Promise<Resume[]>;
  getResume(id: number): Promise<Resume | undefined>;
  createResume(resume: InsertResume): Promise<Resume>;
  updateResume(id: number, updates: Partial<Resume>): Promise<Resume>;

  // Badges
  getBadges(): Promise<Badge[]>;
  getUserBadges(userId: string): Promise<UserBadge[]>;
  awardBadge(userId: string, badgeId: number): Promise<UserBadge>;
  createBadge(badge: any): Promise<Badge>; // For seeding

  // Notifications
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: number): Promise<Notification>;
}

export class DatabaseStorage implements IStorage {
  // Courses
  async getCourses(category?: string): Promise<Course[]> {
    if (category) {
      return db.select().from(courses).where(eq(courses.category, category));
    }
    return db.select().from(courses);
  }

  async getCourse(id: number): Promise<(Course & { modules: Module[] }) | undefined> {
    const course = await db.query.courses.findFirst({
      where: eq(courses.id, id),
      with: {
        modules: {
          orderBy: (modules, { asc }) => [asc(modules.order)],
        },
      },
    });
    return course;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db.insert(courses).values(course).returning();
    return newCourse;
  }

  async createModule(module: InsertModule): Promise<Module> {
    const [newModule] = await db.insert(modules).values(module).returning();
    return newModule;
  }

  // Progress
  async getUserProgress(userId: string, courseId: number): Promise<UserProgress | undefined> {
    const [progress] = await db.select().from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.courseId, courseId)));
    return progress;
  }

  async updateUserProgress(userId: string, courseId: number, moduleId: number, completed: boolean): Promise<UserProgress> {
    // Check if progress record exists
    let progress = await this.getUserProgress(userId, courseId);
    
    if (!progress) {
      // Create new progress record
      const [newProgress] = await db.insert(userProgress).values({
        userId,
        courseId,
        completedModules: completed ? [moduleId] : [],
        progress: 0, // Calculate properly based on total modules
      }).returning();
      progress = newProgress;
    } else {
      // Update existing
      let completedModules = (progress.completedModules as number[]) || [];
      if (completed) {
        if (!completedModules.includes(moduleId)) {
          completedModules.push(moduleId);
        }
      } else {
        completedModules = completedModules.filter(id => id !== moduleId);
      }
      
      const [updated] = await db.update(userProgress)
        .set({ 
          completedModules, 
          lastAccessed: new Date() 
          // Note: In a real app, calculate % progress here based on total modules count
        })
        .where(eq(userProgress.id, progress.id))
        .returning();
      progress = updated;
    }
    return progress;
  }

  // Interviews
  async getInterviews(userId: string): Promise<Interview[]> {
    return db.select().from(interviews)
      .where(eq(interviews.userId, userId))
      .orderBy(desc(interviews.createdAt));
  }

  async getInterview(id: number): Promise<Interview | undefined> {
    const [interview] = await db.select().from(interviews).where(eq(interviews.id, id));
    return interview;
  }

  async createInterview(interview: InsertInterview): Promise<Interview> {
    const [newInterview] = await db.insert(interviews).values(interview).returning();
    return newInterview;
  }

  async updateInterview(id: number, updates: Partial<Interview>): Promise<Interview> {
    const [updated] = await db.update(interviews).set(updates).where(eq(interviews.id, id)).returning();
    return updated;
  }

  // Resumes
  async getResumes(userId: string): Promise<Resume[]> {
    return db.select().from(resumes)
      .where(eq(resumes.userId, userId))
      .orderBy(desc(resumes.createdAt));
  }

  async getResume(id: number): Promise<Resume | undefined> {
    const [resume] = await db.select().from(resumes).where(eq(resumes.id, id));
    return resume;
  }

  async createResume(resume: InsertResume): Promise<Resume> {
    const [newResume] = await db.insert(resumes).values(resume).returning();
    return newResume;
  }

  async updateResume(id: number, updates: Partial<Resume>): Promise<Resume> {
    const [updated] = await db.update(resumes).set(updates).where(eq(resumes.id, id)).returning();
    return updated;
  }

  // Badges
  async getBadges(): Promise<Badge[]> {
    return db.select().from(badges);
  }

  async createBadge(badge: any): Promise<Badge> {
    const [newBadge] = await db.insert(badges).values(badge).returning();
    return newBadge;
  }

  async getUserBadges(userId: string): Promise<UserBadge[]> {
    return db.select().from(userBadges).where(eq(userBadges.userId, userId));
  }

  async awardBadge(userId: string, badgeId: number): Promise<UserBadge> {
    const [awarded] = await db.insert(userBadges).values({ userId, badgeId }).returning();
    return awarded;
  }

  // Notifications
  async getNotifications(userId: string): Promise<Notification[]> {
    return db.select().from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotif] = await db.insert(notifications).values(notification).returning();
    return newNotif;
  }

  async markNotificationRead(id: number): Promise<Notification> {
    const [updated] = await db.update(notifications)
      .set({ read: true })
      .where(eq(notifications.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
