import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { registerAudioRoutes } from "./replit_integrations/audio";
import { openai } from "./replit_integrations/audio"; 

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Setup Audio (for Voice Interview features)
  registerAudioRoutes(app);

  // --- API Routes ---

  // Courses
  app.get(api.courses.list.path, async (req, res) => {
    const category = req.query.category as string | undefined;
    const courses = await storage.getCourses(category);
    res.json(courses);
  });

  app.get(api.courses.get.path, async (req, res) => {
    const course = await storage.getCourse(Number(req.params.id));
    if (!course) return res.status(404).json({ message: "Course not found" });
    res.json(course);
  });

  // Progress (Protected)
  app.get(api.progress.get.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const progress = await storage.getUserProgress(userId, Number(req.params.courseId));
    if (!progress) return res.status(404).json({ message: "Progress not found" });
    res.json(progress);
  });

  app.post(api.progress.update.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const { moduleId, completed } = req.body;
    const progress = await storage.updateUserProgress(userId, Number(req.params.courseId), moduleId, completed);
    res.json(progress);
  });

  // Interviews (Protected)
  app.get(api.interviews.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const interviews = await storage.getInterviews(userId);
    res.json(interviews);
  });

  app.post(api.interviews.create.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const interviewData = { ...req.body, userId };
    const interview = await storage.createInterview(interviewData);
    res.status(201).json(interview);
  });

  app.get(api.interviews.get.path, isAuthenticated, async (req: any, res) => {
    const interview = await storage.getInterview(Number(req.params.id));
    if (!interview || interview.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: "Interview not found" });
    }
    res.json(interview);
  });

  app.post(api.interviews.analyze.path, isAuthenticated, async (req: any, res) => {
    // Mock AI analysis for now - in production this would use OpenAI
    const interview = await storage.getInterview(Number(req.params.id));
    if (!interview || interview.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: "Interview not found" });
    }

    // Example AI Call (Conceptual):
    /*
    const completion = await openai.chat.completions.create({
      model: "gpt-5.1",
      messages: [
        { role: "system", content: "Analyze this interview transcript..." },
        { role: "user", content: JSON.stringify(interview.transcript) }
      ]
    });
    */
    
    // For now, simulate analysis update
    const updated = await storage.updateInterview(interview.id, {
      score: 85,
      feedback: {
        strengths: ["Clear communication", "Good technical knowledge"],
        weaknesses: ["Could provide more concrete examples"],
        summary: "Strong performance overall."
      }
    });

    res.json(updated);
  });

  // Resumes (Protected)
  app.get(api.resumes.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const resumes = await storage.getResumes(userId);
    res.json(resumes);
  });

  app.post(api.resumes.create.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const resumeData = { ...req.body, userId };
    const resume = await storage.createResume(resumeData);
    res.status(201).json(resume);
  });

  app.post(api.resumes.improve.path, isAuthenticated, async (req: any, res) => {
     // AI Improvement simulation
    const resume = await storage.getResume(Number(req.params.id));
    if (!resume || resume.userId !== req.user.claims.sub) {
      return res.status(404).json({ message: "Resume not found" });
    }

    const updated = await storage.updateResume(resume.id, {
      improvements: {
        suggestions: ["Use stronger action verbs", "Quantify achievements"],
        optimizedContent: resume.content + "\n\n[AI Optimized Version]"
      }
    });

    res.json(updated);
  });

  // Gamification (Public/Protected mixed)
  app.get(api.badges.list.path, isAuthenticated, async (req: any, res) => {
    const allBadges = await storage.getBadges();
    const userId = req.user?.claims?.sub;
    
    let userBadges: any[] = [];
    if (userId) {
      userBadges = await storage.getUserBadges(userId);
    }

    const badgesWithStatus = allBadges.map(b => ({
      ...b,
      earned: userBadges.some(ub => ub.badgeId === b.id)
    }));
    
    res.json(badgesWithStatus);
  });

  app.get(api.notifications.list.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const notifications = await storage.getNotifications(userId);
    res.json(notifications);
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingCourses = await storage.getCourses();
  if (existingCourses.length === 0) {
    const webDev = await storage.createCourse({
      title: "Full Stack Web Development",
      description: "Master modern web development with React, Node.js, and PostgreSQL.",
      category: "Development",
      difficulty: "Intermediate",
      duration: 2400, // 40 hours
      published: true,
      imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80",
      aiSummary: "A comprehensive guide to building scalable web applications."
    });

    await storage.createModule({
      courseId: webDev.id,
      title: "Introduction to React",
      content: "# React Basics\n\nLearn about Components, Props, and State.",
      order: 1
    });
    
    await storage.createModule({
      courseId: webDev.id,
      title: "Backend with Express",
      content: "# Express.js\n\nBuilding REST APIs with Node.js.",
      order: 2
    });

    const mlCourse = await storage.createCourse({
      title: "Machine Learning Fundamentals",
      description: "Introduction to ML concepts using Python and TensorFlow.",
      category: "Data Science",
      difficulty: "Advanced",
      duration: 3000,
      published: true,
      imageUrl: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?auto=format&fit=crop&w=800&q=80",
      aiSummary: "Learn the math and code behind intelligent systems."
    });

    // Badges
    await storage.createBadge({
      name: "Fast Learner",
      description: "Completed first module in record time.",
      icon: "Zap",
      category: "Speed"
    });
    
    await storage.createBadge({
      name: "Code Warrior",
      description: "Completed 5 coding challenges.",
      icon: "Sword",
      category: "Skill"
    });

    await storage.createCourse({
      title: "Advanced System Design (Part 2)",
      description: "Deep dive into distributed systems, microservices, and high-availability architectures.",
      category: "System Design",
      difficulty: "Advanced",
      duration: 0,
      published: false,
      imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80",
      aiSummary: "Coming Soon: The next chapter in your architecture journey."
    });
  }
}
