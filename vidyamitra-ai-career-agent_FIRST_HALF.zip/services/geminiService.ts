
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ResumeAnalysis, LearningModule } from "../types.ts";

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Wrapper to handle 429 errors and implement simple retry logic
async function apiCall<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    if (error.message?.includes("429") || error.message?.includes("RESOURCE_EXHAUSTED")) {
      console.warn("Quota exceeded. Retrying in 2 seconds...");
      await sleep(2000);
      try {
        return await fn();
      } catch (retryError: any) {
        throw new Error("The AI is currently under heavy load. Please wait a minute before trying again.");
      }
    }
    throw error;
  }
}

export const analyzeResume = async (fileData?: { data: string, mimeType: string }, textContent?: string): Promise<ResumeAnalysis> => {
  return apiCall(async () => {
    // Fixed: Always use direct process.env.API_KEY initialization inside call
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const parts: any[] = [];
    
    if (fileData) {
      parts.push({
        inlineData: {
          data: fileData.data,
          mimeType: fileData.mimeType
        }
      });
    }

    const prompt = `Analyze this resume with high precision. 
      1. Market Readiness Score (0-100).
      2. Top strengths.
      3. Improvement recommendations.
      4. Executive summary.
      Return strictly JSON.
      ${textContent ? `Text: ${textContent}` : ''}`;

    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            personalInfo: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                email: { type: Type.STRING },
                phone: { type: Type.STRING },
                location: { type: Type.STRING }
              },
              required: ["name", "email", "phone", "location"]
            },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
            summary: { type: Type.STRING }
          },
          required: ["score", "personalInfo", "skills", "strengths", "recommendations", "summary"]
        }
      }
    });

    // Fixed: Using .text property directly
    return JSON.parse(response.text || '{}');
  });
};

export const generateLearningPath = async (skills: string[], targetRole: string): Promise<LearningModule[]> => {
  return apiCall(async () => {
    // Fixed: Always use direct process.env.API_KEY initialization inside call
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Generate a 4-week roadmap for ${targetRole} focusing on ${skills.join(', ')}. 
      For each module, provide one YouTube search URL in the resources array.
      Return JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              duration: { type: Type.STRING },
              level: { type: Type.STRING },
              tasks: { type: Type.ARRAY, items: { type: Type.STRING } },
              resources: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    link: { type: Type.STRING },
                    type: { type: Type.STRING }
                  },
                  required: ["title", "link", "type"]
                }
              }
            },
            required: ["id", "title", "description", "tasks", "resources"]
          }
        }
      }
    });
    // Fixed: Using .text property directly
    return JSON.parse(response.text || '[]');
  });
};

export const getInterviewQuestion = async (role: string, context: string[]): Promise<string> => {
  return apiCall(async () => {
    // Fixed: Always use direct process.env.API_KEY initialization inside call
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `You are an interviewer for ${role}. History:\n${context.join('\n')}\nAsk the next question.`,
    });
    // Fixed: Using .text property directly
    return response.text || "Tell me about your most challenging project.";
  });
};

export const getMarketInsights = async (role: string, location: string = "Global"): Promise<{ text: string, links: any[] }> => {
  return apiCall(async () => {
    // Fixed: Always use direct process.env.API_KEY initialization inside call
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Market analysis for ${role} in ${location}. Include salary ranges and skills. Use Google Search.`,
      config: { tools: [{ googleSearch: {} }] },
    });
    // Fixed: Using .text property directly
    return {
      text: response.text || "Market data not found.",
      links: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  });
};
