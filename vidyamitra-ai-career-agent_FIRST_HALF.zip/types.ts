
export interface UserProfile {
  name: string;
  email: string;
  skills: string[];
  experience: string;
  targetRole?: string;
}

export interface ResumeAnalysis {
  score: number;
  personalInfo: {
    name: string;
    email: string;
    phone: string;
    location: string;
  };
  skills: string[];
  strengths: string[];
  recommendations: string[];
  summary: string;
}

export interface LearningModule {
  id: string;
  title: string;
  description: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  tasks: string[];
  resources: {
    title: string;
    link: string;
    type: 'video' | 'article' | 'course';
  }[];
}

export interface InterviewMessage {
  role: 'interviewer' | 'candidate';
  text: string;
  timestamp: number;
}

export interface JobInsight {
  title: string;
  company: string;
  location: string;
  salary: string;
  matchScore: number;
  link: string;
}
