
import React, { useState, useEffect } from 'react';
import { 
  Calendar, 
  BookOpen, 
  PlayCircle, 
  ExternalLink, 
  CheckCircle2, 
  ChevronRight,
  Loader2,
  RefreshCcw,
  AlertCircle,
  BrainCircuit,
  Youtube,
  Search as SearchIcon,
  Sparkles
} from 'lucide-react';
import { generateLearningPath } from '../services/geminiService';
import { LearningModule } from '../types';

const LearningPath: React.FC = () => {
  const [modules, setModules] = useState<LearningModule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(0);
  const [userRole, setUserRole] = useState('Full Stack Developer');
  const [searchInput, setSearchInput] = useState('Full Stack Developer');

  const loadPath = async (roleToSearch: string) => {
    setLoading(true);
    setError(null);
    try {
      // We pass common relevant skills or let the AI infer them based on the role
      const skills = ['Fundamentals', 'Advanced Concepts', 'Project Building', 'Specialization'];
      const path = await generateLearningPath(skills, roleToSearch);
      
      if (path && Array.isArray(path) && path.length > 0) {
        setModules(path);
        setUserRole(roleToSearch);
      } else {
        throw new Error("Learning roadmap format invalid or empty.");
      }
    } catch (err: any) {
      console.error("Learning path error:", err);
      setError(err.message || "Failed to generate your career roadmap. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPath(userRole);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      loadPath(searchInput);
    }
  };

  if (loading) {
    return (
      <div className="h-[65vh] flex flex-col items-center justify-center space-y-8 animate-in fade-in duration-500">
        <div className="w-24 h-24 relative">
          <div className="absolute inset-0 border-4 border-cyan-50 rounded-[2.5rem] transform rotate-45"></div>
          <div className="absolute inset-0 border-4 border-[#06B6D4] rounded-[2.5rem] border-t-transparent animate-spin transform rotate-45"></div>
          <BrainCircuit className="absolute inset-0 m-auto w-10 h-10 text-[#06B6D4] animate-pulse" />
        </div>
        <div className="text-center">
          <h3 className="text-2xl font-black text-[#0F172A]">Synthesizing Curriculum</h3>
          <p className="text-slate-500 mt-2 font-medium">Assembling modules and YouTube learning resources for <span className="text-blue-500">{searchInput}</span>...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-[65vh] flex flex-col items-center justify-center space-y-6">
        <div className="w-20 h-20 bg-rose-50 rounded-3xl flex items-center justify-center">
          <AlertCircle className="w-10 h-10 text-rose-500" />
        </div>
        <div className="text-center">
          <h3 className="text-xl font-black text-[#0F172A]">{error}</h3>
          <button 
            onClick={() => loadPath(userRole)}
            className="mt-6 flex items-center space-x-2 bg-[#3B82F6] text-white px-8 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-600 transition-all shadow-xl cursor-pointer"
          >
            <RefreshCcw className="w-4 h-4 mr-2" />
            <span>Retry Path Synthesis</span>
          </button>
        </div>
      </div>
    );
  }

  const currentModule = modules[activeTab];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-[#0F172A]">Skill Progression Matrix</h2>
          <p className="text-slate-500 mt-2 font-medium">AI-optimized curriculum targeting: <span className="text-[#3B82F6] font-bold">{userRole}</span></p>
        </div>
        
        <form onSubmit={handleSearch} className="flex items-center space-x-3 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm focus-within:ring-2 focus-within:ring-blue-100 transition-all">
          <div className="flex items-center px-3 space-x-2 border-r border-slate-100">
            <SearchIcon className="w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              value={searchInput} 
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search another role..." 
              className="bg-transparent border-none focus:outline-none text-sm font-bold text-[#0F172A] w-48"
            />
          </div>
          <button 
            type="submit"
            className="bg-[#0F172A] text-white px-6 py-2.5 rounded-xl font-black uppercase text-[9px] tracking-widest hover:bg-slate-800 transition-all flex items-center cursor-pointer"
          >
            <Sparkles className="w-3 h-3 mr-2 text-cyan-400" />
            Generate Roadmap
          </button>
        </form>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
        <div className="space-y-4">
          {modules.map((mod, i) => (
            <button
              key={mod.id || i}
              onClick={() => setActiveTab(i)}
              className={`w-full flex items-center p-5 rounded-3xl transition-all border-2 text-left group relative overflow-hidden cursor-pointer ${
                activeTab === i 
                  ? 'bg-[#0F172A] border-[#0F172A] text-white shadow-2xl shadow-slate-900/20' 
                  : 'bg-white border-slate-100 text-slate-600 hover:border-cyan-200'
              }`}
            >
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mr-5 shrink-0 transition-all ${
                activeTab === i ? 'bg-cyan-500 text-white' : 'bg-slate-50 group-hover:bg-cyan-50'
              }`}>
                <span className="text-sm font-black italic">M{i+1}</span>
              </div>
              <div className="flex-1 overflow-hidden">
                <p className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${activeTab === i ? 'text-cyan-400' : 'text-slate-400'}`}>Stage {i+1}</p>
                <h4 className="font-black text-sm truncate">{mod.title}</h4>
              </div>
              <ChevronRight className={`w-5 h-5 ml-2 transition-transform ${activeTab === i ? 'translate-x-1 text-cyan-400' : 'text-slate-200'}`} />
            </button>
          ))}
        </div>

        <div className="lg:col-span-3">
          <div className="bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-xl relative overflow-hidden min-h-[500px]">
             {currentModule ? (
               <div className="relative z-10">
                  <div className="flex items-center justify-between mb-10">
                    <div className="flex items-center space-x-4">
                      <div className="px-4 py-1.5 bg-cyan-50 text-[#06B6D4] rounded-xl text-[10px] font-black uppercase tracking-widest border border-cyan-100">
                        {currentModule.level || 'Strategic'} Intensity
                      </div>
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{currentModule.duration || 'Flexible Timeline'}</div>
                    </div>
                  </div>

                  <h3 className="text-4xl font-black text-[#0F172A] mb-4 tracking-tight leading-none">{currentModule.title}</h3>
                  <p className="text-slate-500 mb-12 max-w-2xl font-medium leading-relaxed italic border-l-4 border-blue-500 pl-6 py-1">
                    "{currentModule.description}"
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                    <div className="space-y-8">
                      <h4 className="text-sm font-black text-[#0F172A] flex items-center uppercase tracking-[0.2em] opacity-50">
                        Core Objectives
                      </h4>
                      <ul className="space-y-5">
                        {currentModule.tasks?.map((task, idx) => (
                          <li key={idx} className="flex items-start group">
                            <div className="mt-1 w-6 h-6 rounded-lg border-2 border-slate-100 flex items-center justify-center mr-4 shadow-sm bg-white">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                            </div>
                            <span className="text-sm font-bold text-slate-600 transition-colors leading-tight">{task}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="space-y-8">
                      <h4 className="text-sm font-black text-[#0F172A] flex items-center uppercase tracking-[0.2em] opacity-50">
                        Video & Web Resources
                      </h4>
                      <div className="space-y-4">
                        {currentModule.resources?.map((res, idx) => (
                          <a 
                            key={idx} 
                            href={res.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center p-5 bg-slate-50 rounded-3xl hover:bg-white hover:shadow-2xl hover:border-blue-100 transition-all group border border-transparent cursor-pointer"
                          >
                            <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center mr-5 group-hover:bg-[#3B82F6] transition-all">
                              {res.link.includes('youtube.com') ? <Youtube className="w-6 h-6 text-rose-500 group-hover:text-white" /> : (res.type === 'video' ? <PlayCircle className="w-6 h-6 text-[#3B82F6] group-hover:text-white" /> : <BookOpen className="w-6 h-6 text-[#06B6D4] group-hover:text-white" />)}
                            </div>
                            <div className="flex-1 overflow-hidden">
                              <h5 className="text-sm font-black text-[#0F172A] truncate group-hover:text-[#3B82F6] transition-colors">{res.title}</h5>
                              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{res.link.includes('youtube.com') ? 'YouTube Resource' : `${res.type} Resource`}</p>
                            </div>
                            <ExternalLink className="w-4 h-4 text-slate-300 group-hover:text-[#3B82F6] ml-2" />
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
               </div>
             ) : (
               <div className="h-full flex items-center justify-center text-slate-400 italic">
                 Curriculum data empty.
               </div>
             )}
             <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-cyan-50/20 rounded-full blur-[100px] -mr-[250px] -mt-[250px]"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LearningPath;
