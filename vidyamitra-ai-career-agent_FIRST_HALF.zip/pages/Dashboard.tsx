
import React from 'react';
import { 
  TrendingUp, 
  Award, 
  Zap, 
  Clock, 
  ChevronRight,
  Rocket,
  FileText,
  Map,
  GraduationCap,
  Star,
  TrendingUp as TrendIcon,
  Briefcase
} from 'lucide-react';

interface Activity {
  title: string;
  time: string;
  type: string;
}

interface DashboardProps {
  onNavigate: (page: any) => void;
  activities: Activity[];
  badgeCount: number;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, activities, badgeCount }) => {
  const stats = [
    { label: 'Skills Assessed', value: '12', icon: Zap, bg: 'bg-cyan-50', color: 'text-cyan-600' },
    { label: 'Badges Earned', value: badgeCount.toString(), icon: Award, bg: 'bg-blue-50', color: 'text-blue-600' },
    { label: 'Profile Score', value: '85%', icon: TrendingUp, bg: 'bg-emerald-50', color: 'text-emerald-600' },
    { label: 'Streak Days', value: '15', icon: Clock, bg: 'bg-rose-50', color: 'text-rose-600' },
  ];

  const quickActions = [
    { title: 'Resume Diagnostic', desc: 'AI scan & score', icon: <FileText className="w-5 h-5 text-blue-500" />, page: 'resume' },
    { title: 'Market Intelligence', desc: 'Real-time indexing', icon: <TrendingUp className="w-5 h-5 text-cyan-500" />, page: 'market' },
    { title: 'Learning Path', desc: 'Roadmap synthesis', icon: <Map className="w-5 h-5 text-emerald-500" />, page: 'path' },
    { title: 'Mock Interview', desc: 'Simulation lab', icon: <Mic2 className="w-5 h-5 text-indigo-500" />, page: 'interview' }
  ];

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all cursor-default group">
            <div className={`${stat.bg} ${stat.color} w-10 h-10 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <h3 className="text-3xl font-black text-[#0F172A]">{stat.value}</h3>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-10">
          <section className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm cursor-default">
            <div className="flex items-center justify-between mb-8">
               <div className="flex items-center space-x-2"><TrendIcon className="w-5 h-5 text-blue-500" /><h3 className="text-xl font-black text-[#0F172A]">Career Projection</h3></div>
               <span className="text-[10px] font-black uppercase text-emerald-500 bg-emerald-50 px-3 py-1 rounded-full tracking-widest">Top 15% Rank</span>
            </div>
            <div className="relative pt-8 pb-4">
              <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-50 -translate-y-1/2 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 w-1/3"></div>
              </div>
              <div className="flex justify-between relative">
                {['2025', '2026', '2028'].map((year, i) => (
                  <div key={i} className="flex flex-col items-center cursor-default">
                    <div className={`w-8 h-8 rounded-full border-4 ${i === 0 ? 'bg-blue-500 border-white ring-4 ring-blue-50' : 'bg-white border-slate-100'}`} />
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-4">{year}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {quickActions.map((action, i) => (
              <button key={i} onClick={() => onNavigate(action.page)} className="bg-white p-6 rounded-2xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/20 transition-all flex items-center text-left cursor-pointer group">
                <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mr-4 group-hover:bg-white transition-colors">{action.icon}</div>
                <div><h4 className="font-bold text-[#0F172A]">{action.title}</h4><p className="text-xs text-slate-400 mt-0.5">{action.desc}</p></div>
              </button>
            ))}
          </section>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm h-fit">
          <h3 className="text-sm font-black text-[#0F172A] uppercase tracking-widest mb-6 flex items-center">
            <Clock className="w-4 h-4 mr-2 text-blue-500" />Activity Log
          </h3>
          <div className="space-y-4">
            {activities.map((act, i) => (
              <div key={i} className="flex items-start space-x-3 pb-4 border-b border-slate-50 last:border-0 last:pb-0">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-700 leading-tight">{act.title}</p>
                  <p className="text-[9px] font-black text-slate-400 mt-1 uppercase">{act.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
import { Mic2 } from 'lucide-react';
