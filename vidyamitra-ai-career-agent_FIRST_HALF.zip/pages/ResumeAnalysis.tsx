
import React, { useState, useEffect } from 'react';
import { 
  Upload, 
  Loader2, 
  CheckCircle2, 
  ChevronRight, 
  User,
  GraduationCap,
  Briefcase,
  Code,
  Zap,
  FileText,
  Target,
  Trophy,
  Download,
  AlertTriangle,
  RotateCcw,
  Search,
  Layout
} from 'lucide-react';
// Fixed: Removed non-existent export generateResumeFromData
import { analyzeResume } from '../services/geminiService.ts';
import { ResumeAnalysis } from '../types.ts';

interface ResumeAnalysisPageProps {
  onComplete?: () => void;
}

type FlowStep = 'choice' | 'upload' | 'builder' | 'result';

const ResumeAnalysisPage: React.FC<ResumeAnalysisPageProps> = ({ onComplete }) => {
  const [step, setStep] = useState<FlowStep>('choice');
  const [builderStep, setBuilderStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [gaugeValue, setGaugeValue] = useState(0);
  const [displayScore, setDisplayScore] = useState(0);

  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phone: '', location: '', summary: '',
    education: [{ school: '', degree: '', field: '', date: '' }],
    experience: [{ company: '', role: '', desc: '', date: '' }],
    projects: [{ title: '', desc: '', link: '' }],
    skills: ''
  });

  useEffect(() => {
    if (step === 'result' && analysis) {
      setGaugeValue(0);
      setDisplayScore(0);
      
      const targetScore = analysis.score || 0;
      const duration = 1500;
      const startTime = performance.now();

      const animate = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const currentScore = Math.round(progress * targetScore);
        setDisplayScore(currentScore);
        setGaugeValue(progress * targetScore);

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    }
  }, [step, analysis]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setIsProcessing(true);
    setProcessingStatus('Reading file...');

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        setProcessingStatus('Consulting AI Vision...');
        const base64Content = (event.target?.result as string).split(',')[1];
        const result = await analyzeResume({
          data: base64Content,
          mimeType: file.type
        });
        setAnalysis(result);
        setStep('result');
        if (onComplete) onComplete();
      } catch (err: any) {
        let msg = err.message || "";
        if (msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED")) {
          setError("API Quota Reached. Please try again in 1 minute.");
        } else {
          setError("Failed to analyze resume. Please check your file.");
        }
      } finally {
        setIsProcessing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const downloadAnalysis = () => {
    if (!analysis) return;
    const content = `VidyaMitra AI Resume Diagnostic\n----------------------------\n\nCandidate: ${analysis.personalInfo.name}\nMarket Readiness Score: ${analysis.score}%\n\nExecutive Summary:\n${analysis.summary}\n\nTop Strengths:\n${analysis.strengths.map(s => `- ${s}`).join('\n')}\n\nRecommendations:\n${analysis.recommendations.map(r => `- ${r}`).join('\n')}\n\nKey Skills Identified:\n${analysis.skills.join(', ')}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${analysis.personalInfo.name.replace(/\s+/g, '_')}_Career_Diagnostic.txt`;
    a.click();
  };

  const renderChoice = () => (
    <div className="max-w-4xl mx-auto py-12 space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-black text-[#0F172A]">Professional Diagnostic</h2>
        <p className="text-slate-500 text-lg font-medium max-w-xl mx-auto">Upload your current resume or build an AI-optimized profile from scratch.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <button onClick={() => setStep('upload')} className="group bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-sm hover:border-emerald-500/30 hover:shadow-xl transition-all text-center space-y-6 cursor-pointer">
          <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform"><CheckCircle2 className="w-10 h-10 text-emerald-500" /></div>
          <div><h3 className="text-2xl font-black text-[#0F172A]">Scan Existing</h3><p className="text-slate-400 font-bold mt-1">AI parsing & scoring</p></div>
        </button>
        <button onClick={() => setStep('builder')} className="group bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-sm hover:border-blue-500/30 hover:shadow-xl transition-all text-center space-y-6 cursor-pointer">
          <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform"><Code className="w-10 h-10 text-blue-500" /></div>
          <div><h3 className="text-2xl font-black text-[#0F172A]">AI Builder</h3><p className="text-slate-400 font-bold mt-1">Template-free synthesis</p></div>
        </button>
      </div>
    </div>
  );

  const renderResult = () => {
    if (!analysis) return null;
    const strokeDasharray = 628;
    const offset = strokeDasharray - (strokeDasharray * gaugeValue) / 100;
    const colorClass = gaugeValue > 70 ? 'text-emerald-500' : gaugeValue > 40 ? 'text-amber-500' : 'text-rose-500';

    return (
      <div className="max-w-5xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-700">
        <div className="text-center"><h2 className="text-5xl font-black text-[#0F172A] tracking-tight">Diagnostic Index</h2></div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 flex flex-col items-center justify-center bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl">
            <div className="relative w-64 h-64 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 288 288">
                <circle cx="144" cy="144" r="100" stroke="currentColor" strokeWidth="18" fill="transparent" className="text-slate-50" />
                <circle cx="144" cy="144" r="100" stroke="currentColor" strokeWidth="18" fill="transparent" strokeDasharray={strokeDasharray} strokeDashoffset={offset} strokeLinecap="round" className={`${colorClass} transition-all duration-1000`} />
              </svg>
              <div className="absolute flex flex-col items-center justify-center">
                <span className="text-6xl font-black leading-none">{displayScore}%</span>
                <span className="text-[10px] font-black uppercase text-slate-400 mt-2 tracking-widest">Match Strength</span>
              </div>
            </div>
            <button onClick={downloadAnalysis} className="mt-8 flex items-center space-x-2 text-[#3B82F6] font-black uppercase text-[10px] tracking-widest hover:underline cursor-pointer"><Download className="w-4 h-4" /><span>Download Report</span></button>
          </div>

          <div className="lg:col-span-2 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl space-y-8">
             <div className="flex items-center space-x-3 text-[#0F172A] mb-6"><Target className="w-6 h-6 text-blue-500" /><h3 className="text-2xl font-black">Strategic Feedback</h3></div>
             <p className="text-sm font-medium text-slate-500 italic border-l-4 border-blue-500 pl-4">"{analysis.summary}"</p>
             <div className="grid grid-cols-2 gap-6">
               <div className="space-y-3"><p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Top Assets</p>{analysis.strengths.slice(0,3).map((s,i) => <div key={i} className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-xl text-xs font-bold border border-emerald-100">{s}</div>)}</div>
               <div className="space-y-3"><p className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Growth Vectors</p>{analysis.recommendations.slice(0,3).map((r,i) => <div key={i} className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold border border-blue-100">{r}</div>)}</div>
             </div>
          </div>
        </div>

        <div className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black text-[#0F172A] flex items-center">
              <Layout className="w-5 h-5 mr-3 text-cyan-500" />
              Skill Gap Matrix
            </h3>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Parsed Skills</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {analysis.skills.map((skill, i) => (
              <span key={i} className="px-4 py-2 bg-slate-50 border border-slate-100 rounded-full text-xs font-bold text-slate-600">
                {skill}
              </span>
            ))}
          </div>
        </div>

        <div className="flex justify-center space-x-4">
          <button onClick={() => setStep('choice')} className="flex items-center space-x-3 bg-white border-2 border-slate-100 text-[#0F172A] px-10 py-5 rounded-3xl font-black uppercase text-xs tracking-widest hover:bg-slate-50 transition-all cursor-pointer"><RotateCcw className="w-5 h-5" /><span>Analyze New Profile</span></button>
        </div>
      </div>
    );
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
      {step === 'choice' && renderChoice()}
      {step === 'upload' && (
        <div className="max-w-3xl mx-auto py-12 space-y-12">
          {error && <div className="bg-rose-50 border border-rose-100 p-8 rounded-[2.5rem] flex items-center space-x-6 text-rose-600"><AlertTriangle className="w-10 h-10" /><div><h4 className="font-black text-lg uppercase leading-none mb-2">Diagnostic Error</h4><p className="text-sm font-bold text-rose-500">{error}</p></div></div>}
          <div className="text-center space-y-4"><h2 className="text-4xl font-black text-[#0F172A]">Credential Ingestion</h2><p className="text-slate-400 font-bold">Standard PDF or Image formats are accepted.</p></div>
          <label htmlFor="resume-picker" className={`bg-white border-4 border-dashed rounded-[3rem] p-16 text-center transition-all group relative overflow-hidden block cursor-pointer ${isProcessing ? 'border-blue-500/40 bg-blue-50/10' : 'border-slate-100 hover:border-blue-500/20'}`}>
            <input id="resume-picker" type="file" className="hidden" onChange={handleFileUpload} accept=".pdf,.png,.jpg,.jpeg" disabled={isProcessing} />
            <div className="space-y-6">
              <div className="w-24 h-24 bg-blue-50 rounded-[2rem] flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">{isProcessing ? <Loader2 className="w-10 h-10 text-blue-500 animate-spin" /> : <Upload className="w-10 h-10 text-blue-500" />}</div>
              <p className="text-2xl font-black text-[#0F172A]">{isProcessing ? processingStatus : 'Drop credential here'}</p>
            </div>
          </label>
        </div>
      )}
      {step === 'result' && renderResult()}
    </div>
  );
};

export default ResumeAnalysisPage;
