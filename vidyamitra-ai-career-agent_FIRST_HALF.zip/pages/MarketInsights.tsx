
import React, { useState, useEffect } from 'react';
import { Search, Globe, TrendingUp, ExternalLink, Loader2, Compass, MapPin, SearchCheck, Sparkles } from 'lucide-react';
import { getMarketInsights } from '../services/geminiService';

const MarketInsights: React.FC = () => {
  const [role, setRole] = useState('Full Stack Developer');
  const [location, setLocation] = useState('Global');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<{ text: string, links: any[] } | null>(null);

  const fetchInsights = async () => {
    if (!role.trim()) return;
    setLoading(true);
    setData(null);
    try {
      const insights = await getMarketInsights(role, location);
      setData(insights);
    } catch (error) {
      console.error("Market scan failed", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInsights();
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex-1">
          <h2 className="text-3xl font-black text-[#0F172A] flex items-center"><TrendingUp className="w-8 h-8 mr-3 text-[#06B6D4]" />Market Intelligence</h2>
          <p className="text-slate-500 mt-2 font-medium">Real-time AI indexing for global career trends.</p>
        </div>
        <div className="flex flex-wrap gap-4">
          <div className="bg-white p-2.5 rounded-2xl border border-slate-200 flex items-center space-x-2 w-64 focus-within:border-[#3B82F6] transition-all">
            <SearchCheck className="w-4 h-4 text-slate-400 ml-2" />
            <input value={role} onChange={(e) => setRole(e.target.value)} className="bg-transparent border-none focus:outline-none text-sm w-full font-bold text-[#0F172A]" placeholder="Role" />
          </div>
          <div className="bg-white p-2.5 rounded-2xl border border-slate-200 flex items-center space-x-2 w-56 focus-within:border-[#3B82F6] transition-all">
            <MapPin className="w-4 h-4 text-slate-400 ml-2" />
            <input value={location} onChange={(e) => setLocation(e.target.value)} className="bg-transparent border-none focus:outline-none text-sm w-full font-bold text-[#0F172A]" placeholder="Location" />
          </div>
          <button onClick={fetchInsights} disabled={loading} className="bg-[#0F172A] hover:bg-slate-800 disabled:opacity-50 text-white px-10 py-4 rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] shadow-2xl transition-all cursor-pointer flex items-center">{loading ? <Loader2 className="w-4 h-4 animate-spin mr-3" /> : <Globe className="w-4 h-4 mr-3 text-cyan-400" />}Scan Market</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
        <div className="lg:col-span-3">
          <div className="bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-xl min-h-[500px] relative overflow-hidden">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center space-y-8 animate-pulse"><Compass className="w-16 h-16 text-[#06B6D4] animate-spin" /><p className="text-[#0F172A] font-black text-xl">Aggregating Economic Markers...</p></div>
            ) : data ? (
              <div className="whitespace-pre-wrap leading-relaxed text-lg text-slate-700">
                {data.text.split('\n').map((line, i) => {
                   if (line.startsWith('#')) return <h3 key={i} className="text-2xl font-black mt-8 mb-4 border-b border-slate-50 pb-2 text-[#0F172A]">{line.replace(/#/g, '').trim()}</h3>;
                   if (line.startsWith('*') || line.startsWith('-')) return <li key={i} className="ml-6 mb-2 font-semibold flex items-start"><div className="w-1.5 h-1.5 bg-[#06B6D4] rounded-full mr-3 mt-2 shrink-0"></div>{line.replace(/^[-*]\s*/, '').trim()}</li>;
                   return <p key={i} className="mb-4">{line}</p>;
                })}
              </div>
            ) : <div className="h-full flex flex-col items-center justify-center text-slate-400 italic font-black text-xl"><Search className="w-20 h-20 mb-6 opacity-10" />Scan to view insights</div>}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-xl">
            <h4 className="font-black text-[#0F172A] mb-8 text-xs uppercase tracking-[0.2em]">Validated Sources</h4>
            <div className="space-y-4">
              {data?.links && data.links.length > 0 ? data.links.map((chunk, i) => (
                <a key={i} href={chunk.web?.uri} target="_blank" rel="noopener noreferrer" className="flex items-start justify-between p-5 bg-slate-50 rounded-2xl hover:bg-cyan-50 group transition-all border border-transparent hover:border-cyan-100 shadow-sm cursor-pointer">
                  <div className="overflow-hidden"><span className="text-xs font-black text-slate-700 group-hover:text-[#06B6D4] block truncate mb-1">{chunk.web?.title || 'Report Source'}</span><span className="text-[10px] font-bold text-slate-400 block truncate group-hover:text-cyan-600">{chunk.web?.uri}</span></div>
                  <ExternalLink className="w-4 h-4 text-slate-300 group-hover:text-[#06B6D4] shrink-0 ml-3" />
                </a>
              )) : <div className="text-center py-12 text-[10px] text-slate-300 font-black uppercase tracking-widest">No links yet</div>}
            </div>
          </div>
          <div className="bg-[#0F172A] p-10 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
            <h4 className="font-black text-cyan-400 mb-4 text-xs uppercase tracking-[0.3em] flex items-center"><Sparkles className="w-4 h-4 mr-2" />AI Strategic Insight</h4>
            <p className="text-sm text-slate-300 leading-relaxed font-bold">Market trends indicate significant demand for {role}. High leverage predicted for applicants with strong portfolio validation.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketInsights;
