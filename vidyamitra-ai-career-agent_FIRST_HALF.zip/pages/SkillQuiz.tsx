
import React, { useState, useEffect } from 'react';
import { 
  GraduationCap, 
  HelpCircle, 
  ArrowRight, 
  Clock, 
  Trophy,
  RotateCcw,
  CheckCircle2
} from 'lucide-react';

interface SkillQuizProps {
  onComplete?: (score: number) => void;
  onBadgeEarned?: () => void;
}

const SkillQuiz: React.FC<SkillQuizProps> = ({ onComplete, onBadgeEarned }) => {
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes
  const [isCommitted, setIsCommitted] = useState(false);

  const questions = [
    {
      q: "Which hook is used for side effects in React?",
      options: ["useState", "useEffect", "useMemo", "useRef"],
      a: 1
    },
    {
      q: "What is the correct way to pass state to a child component?",
      options: ["Via Props", "Via State", "Via Context Only", "Via Reference"],
      a: 0
    },
    {
      q: "What does 'LCP' stand for in Core Web Vitals?",
      options: ["Lowest Content Paint", "Largest Contentful Paint", "Layout Content Position", "Last Content Plan"],
      a: 1
    }
  ];

  useEffect(() => {
    let timer: any;
    if (quizStarted && !quizComplete && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0 && quizStarted && !quizComplete) {
      setQuizComplete(true);
      onComplete?.(score);
    }
    return () => clearInterval(timer);
  }, [quizStarted, quizComplete, timeLeft, score]);

  const handleNext = () => {
    let finalScore = score;
    if (selectedAnswer === questions[currentQuestion].a) {
      finalScore += 1;
      setScore(finalScore);
    }
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
      setSelectedAnswer(null);
    } else {
      setQuizComplete(true);
      onComplete?.(finalScore);
    }
  };

  const handleCommit = () => {
    setIsCommitted(true);
    onBadgeEarned?.();
  };

  if (!quizStarted) {
    return (
      <div className="max-w-xl mx-auto bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-xl text-center">
        <GraduationCap className="w-16 h-16 text-blue-500 mx-auto mb-6" />
        <h2 className="text-3xl font-black mb-4">Skill Validation</h2>
        <p className="text-slate-500 mb-8">Prove your expertise and earn your professional badge.</p>
        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 mb-8 text-left space-y-3">
          <div className="flex items-center text-xs font-black uppercase text-slate-400"><Clock className="w-4 h-4 mr-2" /> 2 Minute Time Limit</div>
          <div className="flex items-center text-xs font-black uppercase text-slate-400"><HelpCircle className="w-4 h-4 mr-2" /> 3 Core Questions</div>
        </div>
        <button onClick={() => setQuizStarted(true)} className="w-full bg-[#0F172A] text-white py-4 rounded-2xl font-black uppercase tracking-widest cursor-pointer hover:bg-slate-800 transition-all">Launch Audit</button>
      </div>
    );
  }

  if (quizComplete) {
    return (
      <div className="max-w-xl mx-auto bg-white p-12 rounded-[2.5rem] border border-slate-100 shadow-xl text-center animate-in zoom-in-95">
        <Trophy className="w-16 h-16 text-amber-400 mx-auto mb-6" />
        <h2 className="text-3xl font-black mb-2">Audit Finished</h2>
        <p className="text-sm font-black text-blue-500 uppercase mb-8">Score: {score}/{questions.length}</p>
        <div className="space-y-4">
          {!isCommitted ? (
            <button onClick={handleCommit} className="w-full bg-[#3B82F6] text-white py-4 rounded-2xl font-black uppercase tracking-widest cursor-pointer">Commit to Profile</button>
          ) : (
            <div className="p-4 bg-emerald-50 text-emerald-600 font-black rounded-2xl flex items-center justify-center animate-in fade-in"><CheckCircle2 className="w-4 h-4 mr-2" /> Badge Synchronized</div>
          )}
          <button onClick={() => window.location.reload()} className="w-full bg-slate-100 text-slate-600 py-4 rounded-2xl font-black uppercase tracking-widest cursor-pointer">Retry</button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="flex justify-between items-center px-4">
        <span className="text-xs font-black uppercase text-slate-400">Q {currentQuestion + 1} / {questions.length}</span>
        <span className={`text-xs font-black uppercase ${timeLeft < 20 ? 'text-rose-500 animate-pulse' : 'text-slate-400'}`}>0:{timeLeft.toString().padStart(2, '0')}</span>
      </div>
      <div className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl">
        <h3 className="text-xl font-black text-[#0F172A] mb-8">{questions[currentQuestion].q}</h3>
        <div className="space-y-3">
          {questions[currentQuestion].options.map((opt, i) => (
            <button key={i} onClick={() => setSelectedAnswer(i)} className={`w-full p-5 rounded-2xl text-left font-bold border-2 transition-all cursor-pointer ${selectedAnswer === i ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-slate-50 hover:bg-slate-50 text-slate-600'}`}>
              {opt}
            </button>
          ))}
        </div>
        <button onClick={handleNext} disabled={selectedAnswer === null} className="w-full mt-10 bg-[#0F172A] disabled:opacity-50 text-white py-4 rounded-2xl font-black uppercase tracking-widest cursor-pointer">Continue</button>
      </div>
    </div>
  );
};

export default SkillQuiz;
