
import React, { useState, useEffect, useRef } from 'react';
import { Mic, Send, StopCircle, User, Bot, Loader2, PlayCircle, Trophy, Sparkles } from 'lucide-react';
import { getInterviewQuestion } from '../services/geminiService';
import { InterviewMessage } from '../types';

const MockInterview: React.FC = () => {
  const [messages, setMessages] = useState<InterviewMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [role, setRole] = useState('Full Stack Developer');
  const [sessionActive, setSessionActive] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      setTimeout(() => {
        scrollRef.current!.scrollTop = scrollRef.current!.scrollHeight;
      }, 0);
    }
  }, [messages, isThinking]);

  const startSession = async () => {
    setMessages([]);
    setFeedback(null);
    setSessionActive(true);
    setIsThinking(true);
    try {
      const q = await getInterviewQuestion(role, ["System: Start interview. Introduce yourself professionally and ask an open-ended technical question."]);
      setMessages([{ role: 'interviewer', text: q, timestamp: Date.now() }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsThinking(false);
    }
  };

  const sendMessage = async () => {
    if (!inputText.trim() || isThinking) return;
    const userMsg: InterviewMessage = { role: 'candidate', text: inputText, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsThinking(true);
    try {
      const history = messages.concat(userMsg).map(m => `${m.role === 'interviewer' ? 'Interviewer' : 'Candidate'}: ${m.text}`);
      const nextQ = await getInterviewQuestion(role, history);
      setMessages(prev => [...prev, { role: 'interviewer', text: nextQ, timestamp: Date.now() }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsThinking(false);
    }
  };

  const endSession = () => {
    setSessionActive(false);
    setFeedback("Great session! You demonstrated strong technical clarity. Focus on keeping your behavioral responses more concise for maximum impact.");
  };

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[calc(100vh-12rem)] animate-in fade-in slide-in-from-bottom-4">
      <div className="flex items-center justify-between mb-8">
        <div><h2 className="text-3xl font-black text-[#0F172A]">AI Simulation Lab</h2><p className="text-slate-500 font-medium">Conditioning for high-stakes interviews.</p></div>
        {!sessionActive && (
          <div className="flex items-center space-x-3 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm">
            <input value={role} onChange={(e) => setRole(e.target.value)} className="px-4 py-2 text-sm font-bold text-[#0F172A] focus:outline-none w-48 border-r border-slate-100" />
            <button onClick={startSession} className="bg-[#3B82F6] hover:bg-blue-600 text-white px-8 py-3 rounded-xl font-black uppercase text-[10px] tracking-widest cursor-pointer flex items-center group"><PlayCircle className="w-4 h-4 mr-2 group-hover:scale-110" />Start Session</button>
          </div>
        )}
      </div>

      <div className="flex-1 bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl flex flex-col overflow-hidden relative">
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-10 space-y-8 scroll-smooth pb-20">
          {messages.length === 0 && !sessionActive && !feedback && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-8"><div className="w-28 h-28 bg-cyan-50 rounded-[2.5rem] flex items-center justify-center mb-2 transform -rotate-12 shadow-inner ring-8 ring-white"><Mic className="w-12 h-12 text-[#06B6D4]" /></div><p className="text-2xl font-black text-[#0F172A]">Simulation Idle</p></div>
          )}
          {feedback && (
            <div className="bg-emerald-50 p-8 rounded-3xl border border-emerald-100 text-center animate-in zoom-in-95">
              <Trophy className="w-12 h-12 text-emerald-500 mx-auto mb-4" /><h3 className="text-xl font-black text-emerald-800">Session Analysis</h3><p className="text-emerald-700 font-medium mt-2">{feedback}</p>
              <button onClick={startSession} className="mt-6 text-[10px] font-black uppercase tracking-widest text-emerald-600 hover:underline cursor-pointer">Retry Simulation</button>
            </div>
          )}
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'interviewer' ? 'justify-start' : 'justify-end'} animate-in slide-in-from-bottom-2`}>
              <div className={`flex items-start max-w-[85%] space-x-4 ${msg.role === 'interviewer' ? '' : 'flex-row-reverse space-x-reverse'}`}>
                <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-md ${msg.role === 'interviewer' ? 'bg-[#0F172A] text-cyan-400' : 'bg-blue-600 text-white'}`}>{msg.role === 'interviewer' ? <Bot className="w-6 h-6" /> : <User className="w-6 h-6" />}</div>
                <div className={`p-6 rounded-3xl text-sm font-bold shadow-lg ${msg.role === 'interviewer' ? 'bg-slate-50 text-slate-800 rounded-tl-none border border-slate-100' : 'bg-[#3B82F6] text-white rounded-tr-none'}`}>{msg.text}</div>
              </div>
            </div>
          ))}
          {isThinking && <div className="flex justify-start"><div className="flex items-start space-x-4"><div className="w-10 h-10 rounded-2xl bg-[#0F172A] text-cyan-400 flex items-center justify-center"><Bot className="w-6 h-6" /></div><div className="bg-slate-50 p-6 rounded-3xl rounded-tl-none flex space-x-2 border border-slate-100"><div className="w-2 h-2 bg-[#06B6D4] rounded-full animate-bounce"></div><div className="w-2 h-2 bg-[#06B6D4] rounded-full animate-bounce delay-100"></div><div className="w-2 h-2 bg-[#06B6D4] rounded-full animate-bounce delay-200"></div></div></div></div>}
        </div>

        <div className="p-8 bg-white border-t border-slate-100 relative z-10">
          <div className="flex items-center space-x-4">
            <button className="p-5 text-slate-400 hover:bg-cyan-50 rounded-2xl cursor-pointer transition-all"><Mic className="w-6 h-6" /></button>
            <div className="flex-1 relative">
              <input value={inputText} disabled={!sessionActive || isThinking} onChange={(e) => setInputText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendMessage()} className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-8 py-5 pr-20 focus:outline-none text-base font-bold text-[#0F172A] disabled:opacity-50" placeholder={sessionActive ? "Respond to interviewer..." : "Start session to chat"} />
              <button onClick={sendMessage} disabled={!sessionActive || isThinking || !inputText.trim()} className="absolute right-3 top-1/2 -translate-y-1/2 p-4 bg-[#3B82F6] text-white rounded-xl cursor-pointer hover:bg-blue-700 disabled:opacity-50">{isThinking ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}</button>
            </div>
            {sessionActive && <button onClick={endSession} className="p-5 text-rose-500 hover:bg-rose-50 rounded-2xl cursor-pointer transition-all"><StopCircle className="w-6 h-6" /></button>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MockInterview;
