
import React, { useState, useMemo } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Map, 
  Mic2, 
  Search, 
  GraduationCap, 
  LogOut, 
  Bell, 
  ChevronLeft, 
  Search as SearchIcon, 
  X, 
  Mail, 
  MapPin, 
  Trophy,
  Home
} from 'lucide-react';
import Dashboard from './pages/Dashboard.tsx';
import ResumeAnalysisPage from './pages/ResumeAnalysis.tsx';
import LearningPath from './pages/LearningPath.tsx';
import MockInterview from './pages/MockInterview.tsx';
import SkillQuiz from './pages/SkillQuiz.tsx';
import MarketInsights from './pages/MarketInsights.tsx';

type Page = 'dashboard' | 'resume' | 'path' | 'interview' | 'quiz' | 'market';

interface Activity {
  title: string;
  time: string;
  type: 'resume' | 'quiz' | 'path' | 'interview';
}

interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
}

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'resume', label: 'Resume Parser', icon: FileText },
  { id: 'path', label: 'Learning Path', icon: Map },
  { id: 'interview', label: 'Mock Interview', icon: Mic2 },
  { id: 'quiz', label: 'Skill Quiz', icon: GraduationCap },
  { id: 'market', label: 'Market Insights', icon: Search },
];

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [history, setHistory] = useState<Page[]>(['dashboard']);
  const [badgeCount, setBadgeCount] = useState(8);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);

  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', title: 'New Roadmap', message: 'Your AI Learning Path is ready! We analyzed 15+ job descriptions to generate this custom roadmap for you.', time: '10m ago', read: false },
    { id: '2', title: 'Assessment Success', message: 'Congratulations! You earned the "React Expert" badge by scoring 100% in the advanced quiz.', time: '1h ago', read: false },
    { id: '3', title: 'Market Alert', message: 'Frontend salaries are rising in London. New data shows a 12% increase in base compensation for React roles.', time: '5h ago', read: true },
  ]);

  const [activities, setActivities] = useState<Activity[]>([
    { title: 'Completed Python Assessment', time: '2 hours ago', type: 'quiz' },
    { title: 'Market Trends Scanned', time: 'Yesterday', type: 'quiz' },
  ]);

  const navigateTo = (page: Page) => {
    if (page === currentPage) return;
    setHistory(prev => [...prev, page]);
    setCurrentPage(page);
    setSearchQuery('');
  };

  const goBack = () => {
    if (history.length > 1) {
      const newHistory = [...history];
      newHistory.pop();
      const prev = newHistory[newHistory.length - 1];
      setHistory(newHistory);
      setCurrentPage(prev);
    } else {
      setCurrentPage('dashboard');
    }
  };

  const addActivity = (title: string, type: Activity['type']) => {
    setActivities(prev => [{ title, time: 'Just now', type }, ...prev].slice(0, 5));
    setNotifications(prev => [{ id: Date.now().toString(), title: 'Activity Logged', message: title, time: 'Just now', read: false }, ...prev]);
  };

  const handleBadgeEarned = () => {
    setBadgeCount(prev => prev + 1);
    addActivity("Earned a new Skill Badge!", 'quiz');
  };

  const filteredNavItems = useMemo(() => {
    if (!searchQuery) return NAV_ITEMS;
    return NAV_ITEMS.filter(item => item.label.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [searchQuery]);

  const handleNotificationClick = (notif: Notification) => {
    setNotifications(prev => prev.map(n => n.id === notif.id ? { ...n, read: true } : n));
    setSelectedNotification(notif);
    setShowNotifications(false);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard': return <Dashboard onNavigate={navigateTo} activities={activities} badgeCount={badgeCount} />;
      case 'resume': return <ResumeAnalysisPage onComplete={() => addActivity('Resume Analysis Completed', 'resume')} />;
      case 'path': return <LearningPath />;
      case 'interview': return <MockInterview />;
      case 'quiz': return <SkillQuiz onComplete={(score) => addActivity(`Skill Quiz Completed: ${score}/3`, 'quiz')} onBadgeEarned={handleBadgeEarned} />;
      case 'market': return <MarketInsights />;
      default: return <Dashboard onNavigate={navigateTo} activities={activities} badgeCount={badgeCount} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F8FAFC]">
      <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 lg:translate-x-0">
        <div className="flex flex-col h-full">
          <div className="p-6 flex items-center space-x-3 cursor-pointer" onClick={() => navigateTo('dashboard')}>
            <div className="w-10 h-10 bg-[#0F172A] rounded-xl flex items-center justify-center shadow-lg">
              <GraduationCap className="text-[#06B6D4] w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#0F172A] leading-none">VidyaMitra</h1>
              <span className="text-xs font-medium text-slate-500 uppercase tracking-tighter">AI CAREER AGENT</span>
            </div>
          </div>
          <nav className="flex-1 px-4 py-4 space-y-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id as Page)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer ${
                    currentPage === item.id ? 'bg-cyan-50 text-[#06B6D4]' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${currentPage === item.id ? 'text-[#06B6D4]' : 'text-slate-400'}`} />
                  <span className="font-semibold">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </aside>

      <main className="flex-1 lg:ml-64">
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 px-8 flex items-center justify-between">
          <div className="relative">
            <div className="flex items-center bg-slate-100 px-4 py-2 rounded-full w-96 focus-within:ring-2 focus-within:ring-[#3B82F6]/20 transition-all">
              <SearchIcon className="w-4 h-4 text-slate-400 mr-2" />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Find a tool..." 
                className="bg-transparent border-none focus:outline-none text-sm w-full font-medium"
              />
            </div>
            {searchQuery && (
              <div className="absolute top-full left-0 mt-2 w-full bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden z-50">
                {filteredNavItems.map(item => (
                  <button 
                    key={item.id}
                    onClick={() => navigateTo(item.id as Page)}
                    className="w-full text-left px-6 py-4 hover:bg-slate-50 flex items-center space-x-4 cursor-pointer"
                  >
                    <item.icon className="w-4 h-4 text-slate-400" />
                    <span className="text-sm font-bold text-slate-700">{item.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <button onClick={() => setShowNotifications(!showNotifications)} className="p-2.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-full relative cursor-pointer">
              <Bell className="w-5 h-5" />
              {notifications.some(n => !n.read) && <span className="absolute top-2 right-2 w-3 h-3 bg-rose-500 border-2 border-white rounded-full"></span>}
            </button>
            <div onClick={() => setShowProfileModal(true)} className="flex items-center space-x-3 cursor-pointer p-1 pr-3 rounded-full hover:bg-slate-50 transition-all">
              <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center overflow-hidden">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Shray" alt="Avatar" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </header>

        {/* Floating Notification Detail */}
        {selectedNotification && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setSelectedNotification(null)}></div>
            <div className="relative bg-white rounded-[2.5rem] shadow-2xl max-w-lg w-full p-10">
              <button onClick={() => setSelectedNotification(null)} className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-800 rounded-full cursor-pointer"><X className="w-6 h-6" /></button>
              <h3 className="text-2xl font-black text-[#0F172A] mb-4">{selectedNotification.title}</h3>
              <p className="text-lg text-slate-600 mb-8">{selectedNotification.message}</p>
              <button onClick={() => setSelectedNotification(null)} className="w-full bg-[#0F172A] text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest cursor-pointer">Dismiss</button>
            </div>
          </div>
        )}

        {/* Profile Modal */}
        {showProfileModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setShowProfileModal(false)}></div>
            <div className="relative bg-white rounded-[3rem] shadow-2xl max-w-xl w-full p-12">
              <button onClick={() => setShowProfileModal(false)} className="absolute top-8 right-8 p-2 text-slate-400 hover:text-slate-800 rounded-full cursor-pointer"><X className="w-6 h-6" /></button>
              <div className="text-center mb-10">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Shray" className="w-32 h-32 rounded-full mx-auto mb-6 border-4 border-slate-50 shadow-xl" />
                <h3 className="text-3xl font-black">Shray Soni</h3>
                <div className="flex justify-center mt-6 gap-4">
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100"><p className="text-[10px] font-black text-slate-400 uppercase">Badges</p><p className="text-2xl font-black text-[#0F172A]">{badgeCount}</p></div>
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100"><p className="text-[10px] font-black text-slate-400 uppercase">Reputation</p><p className="text-2xl font-black text-[#0F172A]">2.4k</p></div>
                </div>
              </div>
              <button onClick={() => setShowProfileModal(false)} className="w-full bg-[#3B82F6] text-white py-5 rounded-2xl font-black uppercase tracking-widest cursor-pointer">Close</button>
            </div>
          </div>
        )}

        {/* Back and Home navigation */}
        <div className="p-8 max-w-7xl mx-auto">
          {currentPage !== 'dashboard' && (
            <div className="flex items-center space-x-4 mb-6">
              <button onClick={goBack} className="flex items-center space-x-2 text-slate-500 hover:text-[#3B82F6] transition-colors cursor-pointer">
                <ChevronLeft className="w-4 h-4" /><span className="text-[10px] font-black uppercase tracking-widest">Back</span>
              </button>
              <div className="w-px h-4 bg-slate-200"></div>
              <button onClick={() => navigateTo('dashboard')} className="flex items-center space-x-2 text-slate-500 hover:text-[#3B82F6] transition-colors cursor-pointer">
                <Home className="w-4 h-4" /><span className="text-[10px] font-black uppercase tracking-widest">Home</span>
              </button>
            </div>
          )}
          {renderPage()}
        </div>

        {/* Notification Popup Menu */}
        {showNotifications && (
          <div className="absolute right-8 top-20 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 py-4 z-50">
            {notifications.map(n => (
              <div key={n.id} onClick={() => handleNotificationClick(n)} className="px-6 py-4 hover:bg-slate-50 cursor-pointer border-b border-slate-50 last:border-0">
                <p className={`text-xs font-black ${!n.read ? 'text-blue-600' : 'text-slate-600'}`}>{n.title}</p>
                <p className="text-[10px] text-slate-400 mt-1 truncate">{n.message}</p>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
